/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package chargerlib.undo;

/**
 * An  empty superclass as a placeholder for the 
 * other classes in this package to use in applying steps
 * to undo/redo, etc.
 * @see UndoStateManager
 * @since Charger 3.8.3
 * @author Harry S. Delugach (delugach@uah.edu)
 */
public abstract class UndoableState {
    
    public UndoableState() {
        
    }

}
