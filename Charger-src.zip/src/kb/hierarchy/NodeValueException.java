/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kb.hierarchy;

/**
 *
 * @author Harry Delugach
 */
public class NodeValueException extends Exception {
    
}
