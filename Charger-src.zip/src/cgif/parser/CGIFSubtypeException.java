/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cgif.parser;

/**
 *
 * @author Harry S. Delugach (delugach@uah.edu)
 */
public class CGIFSubtypeException extends Exception {
    
    public CGIFSubtypeException( String msg ) {
        super( msg );
    }
}
